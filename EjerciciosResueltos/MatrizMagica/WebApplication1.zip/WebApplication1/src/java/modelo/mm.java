/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author alejandro
 */
public class mm {

    int[][] m;

    public mm(int d) {
        this.m = new int[d][d];
    }
    public int getD()
    {
        return this.m.length;
    }

   public int[][] get() {

        int i = 0, j = this.m.length / 2;
        for (int k = 1; k <= Math.pow(this.m.length, 2); k++) {

            m[i][j] = k;

            if (k % this.m.length == 0) {
                i++;
            } else {
                i--;
                j--;

                if (i < 0) {
                    i = this.m.length - 1;
                }
                if (j < 0) {
                    j = this.m.length - 1;
                }

            }

        }

        return m;

    }
}
