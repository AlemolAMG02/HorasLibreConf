package ejerciciosInicialesObjetos;

public abstract class Mesa {
	private String nombre;
	private Persona jugador;
	
	public Mesa() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
