package com.example.project1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
	@Controller
	@RequestMapping("/dime")
public class holamundo {
	
	@GetMapping("/holamundo1")
	String saludo1() {
	return"holamundo";
		}
	
	@GetMapping("/holamundo2")
	String saludo2() {
	return"holamundo2";
		}
	
	
	}

